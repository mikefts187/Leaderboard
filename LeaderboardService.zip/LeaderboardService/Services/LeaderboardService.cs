﻿using Leaderboard.Models;
using System.Collections.Concurrent;

namespace Leaderboard.Services
{
    public class LeaderboardService : ILeaderboard
    {
        // 使用并发字典存储客户数据
        private readonly ConcurrentDictionary<long, decimal> _customers = new();

        // 使用SortedSet维护排行榜
        private readonly SortedSet<(decimal Score, long CustomerId)> _leaderboard = new(
            Comparer<(decimal Score, long CustomerId)>.Create((a, b) =>
                a.Score != b.Score ? b.Score.CompareTo(a.Score) : a.CustomerId.CompareTo(b.CustomerId)));

        private readonly ReaderWriterLockSlim _lock = new();

        public decimal UpdateScore(long customerId, decimal scoreDelta)
        {
            // 参数验证
            if (scoreDelta < -1000 || scoreDelta > 1000)
                throw new ArgumentOutOfRangeException(nameof(scoreDelta), "Score delta must be between -1000 and 1000");

            _lock.EnterWriteLock();
            try
            {
                // 获取当前分数或默认0
                _customers.TryGetValue(customerId, out var currentScore);
                var newScore = currentScore + scoreDelta;

                // 如果分数<=0则从排行榜移除
                if (currentScore > 0)
                {
                    _leaderboard.Remove((currentScore, customerId));
                }

                if (newScore > 0)
                {
                    _customers[customerId] = newScore;
                    _leaderboard.Add((newScore, customerId));
                }
                else
                {
                    _customers.TryRemove(customerId, out _);
                }

                return newScore;
            }
            finally
            {
                _lock.ExitWriteLock();
            }
        }

        public List<LeaderboardResponse> GetCustomersByRank(int start, int end)
        {
            if (start < 1 || end < start)
                throw new ArgumentException("Invalid rank range");

            _lock.EnterReadLock();
            try
            {
                var result = new List<LeaderboardResponse>();
                int currentRank = 0;

                foreach (var item in _leaderboard)
                {
                    currentRank++;
                    if (currentRank > end) break;
                    if (currentRank >= start)
                    {
                        result.Add(new LeaderboardResponse
                        {
                            CustomerId = item.CustomerId,
                            Score = item.Score,
                            Rank = currentRank
                        });
                    }
                }

                return result;
            }
            finally
            {
                _lock.ExitReadLock();
            }
        }

        public NeighborsResponse GetCustomerWithNeighbors(long customerId, int high, int low)
        {
            _lock.EnterReadLock();
            try
            {
                if (!_customers.TryGetValue(customerId, out var score) || score <= 0)
                    throw new KeyNotFoundException("Customer not found or has no score");

                // 获取所有客户列表和当前客户的索引
                var leaderboardList = _leaderboard.ToList();
                var currentIndex = leaderboardList.FindIndex(x => x.Score == score && x.CustomerId == customerId);

                if (currentIndex == -1)
                    throw new InvalidOperationException("Customer not found in leaderboard");

                var response = new NeighborsResponse
                {
                    Current = new LeaderboardResponse
                    {
                        CustomerId = customerId,
                        Score = score,
                        Rank = currentIndex + 1
                    }
                };

                // 获取高排名邻居
                response.Higher = Enumerable.Range(1, high)
                    .Select(i => currentIndex - i)
                    .Where(idx => idx >= 0)
                    .Select(idx => new LeaderboardResponse
                    {
                        CustomerId = leaderboardList[idx].CustomerId,
                        Score = leaderboardList[idx].Score,
                        Rank = idx + 1
                    })
                    .ToList();

                // 获取低排名邻居
                response.Lower = Enumerable.Range(1, low)
                    .Select(i => currentIndex + i)
                    .Where(idx => idx < leaderboardList.Count)
                    .Select(idx => new LeaderboardResponse
                    {
                        CustomerId = leaderboardList[idx].CustomerId,
                        Score = leaderboardList[idx].Score,
                        Rank = idx + 1
                    })
                    .ToList();

                return response;
            }
            finally
            {
                _lock.ExitReadLock();
            }
        }
    }
}